<?php
require('conexion.php');

$id_empleado=$_POST['id_empleado'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$dui=$_POST['dui'];
$nombre_empresa=$_POST['nombre_empresa'];
$direccion=$_POST['direccion'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO empleado (id_empleado, nombre, apellido, dui, nombre_empresa, direccion_empresa) VALUES('$id_empleado','$nombre','$apellido','$dui','$nombre_empresa','$direccion')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalEmpleados.php');
	}
	else
	{
		echo 'Sucedio un error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE empleado SET nombre='$nombre',apellido='$apellido',dui='$dui',nombre_empresa='$nombre_empresa',direccion_empresa='$direccion' WHERE id_empleado='$id_empleado'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalEmpleados.php');
	}
	else
	{
		echo 'Error al actualizar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM empleado WHERE id_empleado='$id_empleado'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalEmpleados.php');
	}
	else
	{
		echo 'Error al eliminar';
	}
}
?>