<?php
include('IngresarNuevoEmp.php');
include('Empleado.php');
?>