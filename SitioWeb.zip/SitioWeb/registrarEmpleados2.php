<?php
require('conexion.php');

$nom=$_POST['nombre'];
$dui=$_POST['dui'];
$cor=$_POST['correo'];
$contra=$_POST['contraseña'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO usuario (nombre, dui, correo, contraseña) VALUES ('$nom','$dui','$cor','$contra')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalEmp2.php');
	}
	else
	{
		echo 'Sucedio un error al registrar';
	}
}
?>