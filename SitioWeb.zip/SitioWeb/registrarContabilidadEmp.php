<?php
require('conexion.php');

$id_ingresos=$_POST['encargado'];
$dia=$_POST['dia'];
$cant_ingresos_dia=$_POST['cant_ingresos'];
$cant_egresaron_empresa=$_POST['cant_egresos'];
$detalle=$_POST['Comentarios'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO contabilidad (id_ingreso,dia,cant_ingresos_dia,cant_egresaron_empresa,detalle) VALUES('$id_ingresos','$dia','$cant_ingresos_dia','$cant_egresaron_empresa','$detalle')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalContabilidadEmp.php');
	}
	else
	{
		echo 'Error al registrar';
	}
}
?>