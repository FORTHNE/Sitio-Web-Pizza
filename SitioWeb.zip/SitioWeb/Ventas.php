<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas</title>
    <link rel="stylesheet" href="cliente.css">
    <style type="text/css">
input[type=button],input[type=submit]
{
background-color:#41D00F;
border:none;
color:black;
font-weigth:bold;
padding:6px 20px;
text-aling:center;
font-size:16px;
margin:4px 4px;
box-shadow:3px 3px 3px black;
position:center;
font-family:Arial;
}
#tabla{
background:url(imagenes/fondo-header.jpg);
}

td{
font-family:Arial;
font-weigth:bold;
font-size:20;
background-color:#DDC817;
}
</style>
<!--ENLACE AL STYLE.CSS-->	
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li class=" active">
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                 <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
                
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="container_form">
            <form name="frmVentas" action="registrarVentas.php" method="POST">
                <div>            <h1>Area de ventas</h1>
                    <br><label for="encargado: ">ID Ventas</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" maxlength="12" id="cod3" name="CodVentas" required>
                </div>
                <div>
                    <br><label for="dia: ">Seleccione el dia</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="date" id="dia" name="Dia" required>
                </div>
                <div>
                    <br><label for="Nombre_Empresa: ">Cantidad de ventas en el mes</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="number" id="cantVentas" name="cantidad_ventas" required>
                </div>
                <div>
                    <br><label for="cant_clientes: ">Dinero total</label></br>
                    <input style="WIDTH: 280px; height: 20px;" type="text" id="total" maxlength="50" name="dinero" required>
                </div>
                <div>
                    <br><label for="cant_clientes: ">Cantidad de trabajadores en el area de ventas</label></br>
                    <input style="WIDTH: 280px; height: 20px;" type="number" id="cant_trab" name="canTrabajadores" required>
                </div>
                <div>
             
                <br>
                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
            </form>

        </div>
    </div>

    <div id="tabla">
        <center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Listado de Ventas</label></td></tr>
        <tr>
        <td><label>ID Ventas</label></td>
        <td><label>Seleccione el dia</label></td>
        <td><label>Cantidad de ventas en el mes</label></td>
        <td><label>Dinero total</label></td>
        <td><label>Cantidad de trabajadores en el area de ventas</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM areaventas";
            $result=mysqli_query($conexion,$sql);
                 
                 while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['id_venta'],"</td><td>",$row ['fecha'],"</td><td>",$row['cant_ventas_mes'],"</td><td>",$row['dinero_total'],"</td><td>",$row['cant_trabajadores'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
    </div>
    <div class="footer">
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
    </div>
</body>
</html>