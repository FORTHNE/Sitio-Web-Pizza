var codigo, telefono, sucursal, direccion, gerente, butt;
var output_text;

function validate(){
	codigo = document.forms["input_form"]["codigo"].value;
	telefono = document.forms["input_form"]["telefono"].value;
	sucursal = document.forms["input_form"]["sucursal"].value;
	direccion = document.forms["input_form"]["direccion"].value;
	gerente = document.forms["input_form"]["gerente"].value;
	butt = document.forms["input.form"]["button"].value;

	butt = document.location.href="inicio2.html";
}

