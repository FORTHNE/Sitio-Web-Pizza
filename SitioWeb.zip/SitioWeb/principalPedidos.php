<?php
include('registrarPedidos.php');
include('pedidos.php');
?>