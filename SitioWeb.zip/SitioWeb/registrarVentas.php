<?php
require('conexion.php');

$id_venta=$_POST['CodVentas'];
$dia=$_POST['Dia'];
$cantVentas=$_POST['cantidad_ventas'];
$total=$_POST['dinero'];
$cant_trab=$_POST['canTrabajadores'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO areaventas (id_venta,fecha,cant_ventas_mes,dinero_total,cant_trabajadores) VALUES('$id_venta','$dia','$cantVentas','$total','$cant_trab')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalVentas.php');
	}
	else
	{
		echo 'Error al registrar, Puede ser debido a duplicidad de llave primaria';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE areaventas SET fecha='$dia',cant_ventas_mes='$cantVentas',dinero_total='$total',cant_trabajadores='$cant_trab'WHERE id_venta='$id_venta'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalVentas.php');
	}
	else
	{
		echo 'Error al actualizar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM areaventas WHERE id_venta='$id_venta'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalVentas.php');
	}
	else
	{
		echo 'Error al eliminar';
	}
}
?>