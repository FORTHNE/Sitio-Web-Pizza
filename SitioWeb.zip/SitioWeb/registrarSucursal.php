<?php
require('conexion.php');

$id_sucursal=$_POST['codSucursal'];
$telefono=$_POST['telefonoSucur'];
$nombre_sucursal=$_POST['nombre_sucursal'];
$direccion=$_POST['direccion'];
$nombre_gerente=$_POST['nombre_gerente'];


if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO sucursal (id_sucursales, telefono, nombre_sucursal, direccion, nombre_gerente) VALUES('$id_sucursal','$telefono','$nombre_sucursal','$direccion','$nombre_gerente')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalSucursal.php');
	}
	else
	{
		echo 'Sucedio un error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE sucursal SET telefono='$telefono',nombre_sucursal='$nombre_sucursal',direccion='$direccion',nombre_gerente='$nombre_gerente' WHERE id_sucursales='$id_sucursal'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalSucursal.php');
	}
	else
	{
		echo 'Error al actualizar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM sucursal WHERE id_sucursales='$id_sucursal'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalSucursal.php');
	}
	else
	{
		echo 'Error al eliminar';
	}
}
?>