<?php
include('registrarProveedor.php');
include('Proveedores.php');
?>