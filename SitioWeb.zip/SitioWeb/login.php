<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleado</title>
    <link rel="stylesheet" href="cliente.css">
</head>
<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li class=" active">
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>
    
    <!--Cuerpo-->
	<div class="container">
		<div class="container_form">

			<form name="frmDatos" method="POST" action="registrarEmpleados.php">

				<div>
					<h1>Datos del Empleado</h1>
					<br><label for="apellido: ">ID Empleado:</label></br>
					<input  style="WIDTH: 280px; height: 20px;" type="text" id="idEmpleados" maxlength="30" name="id_empleado" required>
				</div>
				<div>
					<br><label for="apellido: ">Nombre:</label></br>
					<input  style="WIDTH: 280px; height: 20px;" type="text" id="nom" maxlength="30" name="nombre" required>
				</div>
				<div>
					<br><label for="apellido: ">Apellidos:</label></br>
					<input  style="WIDTH: 280px; height: 20px;" type="text" id="apellido" maxlength="30" name="apellido" required>
				</div>
				<div>
					<br><label for="Nombre_Empresa: ">DUI:</label></br>
					<input  style="WIDTH: 280px; height: 20px;" type="text" id="dui" maxlength="50" name="dui" required>
				</div>
				<div>
					<br><label for="sueldo: ">Nombre de la empresa:</label></br>
					<input style="WIDTH: 280px; height: 20px;" type="text" id="Nombre_Empresa" name="nombre_empresa" required>
				</div>
				<div>
					<br><label for="cant_clientes: ">Direccion de la empresa </label></br>
					<input style="WIDTH: 280px; height: 20px;" type="text" id="direccion" name="direccion" required>
				</div>
		
				<br>
                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
				
			</form>

		</div>
		<center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Listado de Empleados</label></td></tr>
        <tr>
        <td><label>Id Empleado</label></td>
        <td><label>Nombres</label></td>
        <td><label>Apellidos</label></td>
        <td><label>Dui</label></td>
        <td><label>Nombre de la Empresa</label></td>
        <td><label>Direccion de la Empresa</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM empleado";
            $result=mysqli_query($conexion,$sql);
                 
            while($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['id_empleado'],"</td><td>",$row ['nombre'],"</td><td>",$row['apellido'],"</td><td>",$row['dui'],"</td><td>",$row['nombre_empresa'],"</td><td>",$row['direccion_empresa'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
	</div>
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
</body>
</html>