<?php
require('conexion.php');

$nom=$_POST['nombre'];
$dui=$_POST['dui'];
$genero=$_POST['sexo'];
$estado=$_POST['estado'];
$cor=$_POST['correo'];
$contra=$_POST['contraseña'];
$direccion=$_POST['direccion'];
$fechaNacimiento=$_POST['nacimiento'];
$fechaTrabajo=date("Y-m-d H:m:s");
$plan=$_POST['medico'];
$telefono=$_POST['telefono'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO usuario (nombre,dui,correo,direccion,sexo,estado,nacimiento,contraseña,telefono,fecha_trabajo,plan_medico) VALUES('$nom','$dui','$cor','$direccion','$genero','$estado','$fechaNacimiento','$contra','$telefono','$fechaTrabajo','$plan')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalEmp.php');
	}
	else
	{
		echo 'Error al registrar';
	}
}
?>