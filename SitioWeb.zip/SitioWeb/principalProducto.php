<?php
include('registrarProducto.php');
include('productos.php');
?>