<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza Nova</title>
    <link rel="stylesheet" href="css/style.css">
	<style type="text/css">
    .mision{
    width: 40%;
    position: absolute;
    top:180px;
    left:50px;
    color: #fff;
    }
    </style>
</head>

<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:iniciar_sesion.php");
}
?>
   <!--NOOOOOOOOOOOO TOOOOOOOOOOOOOOCAAAAAAAAAAAAAAAAAAAAAAAAR XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD-->

   <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li class=" active">
                <a href="indexEmp.php">Inicio</a>
            </li>
            <li>
                <a href="Empleado.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="contabilidadEmp.php">Contabilidad</a>
            </li>
            <li>
                <a href="comentariosEmp.php">Comentarios</a>
            </li> 
            <li>
                <a href="cerrar_sesion.php">Cerrar Sesion</a>
            </li>			
        </ul>
    </nav>
    
    <!--NOOOOOOOOOOOO TOOOOOOOOOOOOOOCAAAAAAAAAAAAAAAAAAAAAAAAR XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD-->
    <div class="container">
        <header class="titulos">
            <div>
			    
                <h1>BIENVENIDOS<br>PIZZA NOVA</h1>
				<h2>Bienvenido:Empleado</h2>
				<br>
				<?php echo $_SESSION['correo']; ?>
            </div>
            <img src="imagenes\header.jpg" alt="Vegetariana">
        </header>
    </div>

    <div class="container_main">
        <div class="contenido_flex">
            <h1 class="titulo_main">SOMOS NOVA RESTAURANT</h1><br>
            <p><b>
                Nos deleitamos en servirle el inigualable sabor de infancia, manteniendo la calidad y frescura de nuestros platillos a los mejores precios.
                Para nuestra empresa es un honor que formes parte de esta gran familia, y puedas trabajar para nuestros clientes que son nuestra prioridad
            </b></p>
        </div>
        <img src="img1.jpg" alt="" width="300px">
    </div>

    <div class="container_des">
        <div class="mision">
            <h2>MISION: </h2>
            <p>Ser el mejor proveedor de pedidos online para nuestros restaurante, con servicio de entrega gratuita, de la forma mas accesible posible para que nuestros clientes se sientan de la mejor manera.</p>
        </div>
        <div class="vision">
            <h2>VISION:</h2>
            <p>Ser una empresa confiable y de calidad, a traves de la inovacion de nuestros servicios para facilitar a los clientes, los pedidos de nuestra variedad de pizzas identificando oportunidades de expancion en el mercado internacional.</p>
        </div>
    </div>
    <!--MODIFICAR CUERPO DEL TRABAJO-->
    
    <!--NOOOOOOOOOOOO TOOOOOOOOOOOOOOCAAAAAAAAAAAAAAAAAAAAAAAAR XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD-->
    <div class="footer">
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
    </div>
</body>
</html>