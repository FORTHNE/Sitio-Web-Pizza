<?php
include ('registrarEmpleados2.php');
include ('Empleado.php');
?>