<html> 
	<head>
		<title>Generando la Base de Datos</title>
	</head>
	<body>
	<h1>Base de Datos</h1>
	<?php
		
      $servidor="localhost";
      $usuario="root";
      $clave="";

      $conexion=mysqli_connect($servidor,$usuario,$clave);

      if($conexion)
      {
    
      }
      else
      {
         echo'no existe';
      }

		$consulta="CREATE DATABASE IF NOT EXISTS pizza_nova";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		mysqli_select_db($conexion, "pizza_nova");
		
		$consulta="DROP TABLE IF EXISTS empleado";
		$EjecutarConsulta=mysqli_query($conexion, $consulta);
		
		$consulta="CREATE TABLE empleado (id_empleado INT PRIMARY KEY AUTO_INCREMENT , nombre varchar(50), apellido varchar(50), dui varchar(12), nombre_empresa varchar(100), direccion_empresa varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion, $consulta);
		
		$consulta="INSERT INTO empleado (id_empleado, nombre, apellido, dui, nombre_empresa, direccion_empresa) VALUES
                   (1,'Daniela Margarita', 'Avalos Ochoa', '563256737-9', 'pizza italiana', 'calle san marcos '),
                   (2,'William Alexis ', 'Avalos Ochoa', '6134719-9', 'Pizza Italiana ', 'Calle Lopez'),
                   (3,'Brayan Edgardo ', 'Avalos Lopez', '6134719-10', 'Pizza Love ', 'Calle Antigua Roma'),
                   (4,'Josue Ricardo ', 'Avalos Ochoa', '6134719-11', 'Pizza Crash ', 'San Lorenzo'),
                   (5,'Steven Edenilson ', 'Rivas Corvera', '6134719-12', 'Pizza VIP', 'San Esteban'),
                   (6,'Maria Del Carmen ', 'De Paz Pineda', '6134719-13', 'Pizza Don Pepe ', 'Avenida Simeon Cañas'),
                   (7,'Darlin Lissete ', 'Coreas Lopez', '6134719-14', 'Pizza Sauce ', 'Barrio Lourdes'),
                   (8,'Arely Idalma ', 'Urrutia Coronado', '6134719-15', 'Pizza Like', 'Calle Pichil'),
                   (9,'Jose German ', 'Martinez Rios', '6134719-16', 'Pizza Italian ', 'San Vicente'),
                   (10,'Michael Adilio', 'Barahona Flores', '6134719-17', 'Pizza Turkey ', 'Calle El Mango')";
		$EjecutarConsulta=mysqli_query($conexion, $consulta);
		
		
		$consulta="DROP TABLE IF EXISTS sucursal";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE sucursal(id_sucursales INT PRIMARY KEY, telefono varchar(9), nombre_sucursal varchar(100), direccion varchar(100), nombre_gerente varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO sucursal (id_sucursales, telefono, nombre_sucursal, direccion, nombre_gerente) VALUES
                  (1, '654200-0', 'Pizza Italiana', 'calle arce', 'Adalberto Perez '),
                  (2, '759802-1', 'Pizza Lucy', 'Santo Tomas', 'Walter Flores'),
                  (3, '759802-2', 'Pizza Mike', 'San Esteban', 'Jose Hernandez'),
                  (4, '759802-3', 'Pizza Turkey', 'San Felipe', 'Josue Cabrera'),
                  (5, '759802-4', 'Pizza Fire', 'Cojutepeque', 'Steven Lopez'),
                  (6, '759802-5', 'Pizza Italian', 'San Vicente', 'Mariela Rivas'),
                  (7, '759802-6', 'Pizza Light', 'San Miguel', 'Cristian Pineda'),
                  (8, '759802-7', 'Pizza Nova Metro', 'San Salvador', 'Marlon Mejia'),
                  (9, '759802-8', 'Pizza Novisima', 'Chalatenango', 'Reina Ferreira'),
                  (10, '75902-9', 'Pizza Novas', 'La libertad', 'Abigail De Paz')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS publicidad";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE publicidad (id_publicidad INT PRIMARY KEY, dia date, cant_dinero_dia varchar(50), cant_dinero_mes varchar(50), cant_trabajadores INT, tipos_publicidad varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO publicidad (id_publicidad, dia, cant_dinero_dia, cant_dinero_mes, cant_trabajadores, tipos_publicidad) VALUES
                  (1, '2021-11-29', '500', '20,000', 18, 'Cabinas moviles'),
                  (2, '2021-10-02', '550', '21,000', 100, 'Cabinas moviles'),
                  (3, '2021-07-11', '400', '17,000', 150, 'Tv, Radio'),
                  (4, '2021-05-01', '350', '15,000', 80, 'Tv, Radio'),
                  (5, '2021-09-05', '600', '25,000', 155, 'Cabinas moviles'),
                  (6, '2021-02-25', '100', '10,000', 45, 'Redes Sociales'),
                  (7, '2021-01-21', '150', '12,000', 50, 'Banner,Brouchore'),
                  (8, '2021-03-20', '700', '27,000', 100, 'Tv, Radio'),
                  (9, '2021-11-30', '650', '25,500', 120, 'Banner,Brouchore'),
                  (10, '2021-08-07', '200', '11,000', 170, 'Redes Sociales')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS proveedores";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE proveedores (id_proveedor INT PRIMARY KEY, Nombre_completo varchar(100), telefono varchar(9), correo varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO proveedores (id_proveedor, Nombre_completo, telefono, correo) VALUES
                   (1,'William Alexis Avalos Ochoa', '61794991', 'williamavalos@gmail.com'),
                   (2,'Pizza Nova Sur', '6788904-1', 'pizzanovaS@gmail.com'),
                   (3,'Pizza Novisima', '6788904-2', 'pizzanovi@gmail.com'),
                   (4,'Pizza Italiana', '67889045-3', 'pizzaIta@gmail.com'),
                   (5,'Pizza Nova Norte', '67889045-4', 'pizzanovaN@gmail.com'),
                   (6,'Pizza Nova Metro', '67889045-5', 'pizzanovaM@gmail.com'),
                   (7,'Pizza Ligth', '67889045-6', 'pizzanovaLigth@gmail.com'),
                   (8,'Pizza Fire', '67889045-8', 'pizzanovaF@gmail.com'),
                   (9,'Pizzas', '67889045-9', 'pizzanovaS@gmail.com'),
                   (10,'Pizza Turkey', '67889045-10', 'pizzanovaTur@gmail.com')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS producto";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE producto(id_producto INT PRIMARY KEY, seleccione_producto varchar(100) )";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO producto (id_producto, seleccione_producto) VALUES
                   (1, 'Embutidos'),
                   (2, 'Aderesos'),
                   (3, 'Verdura'),
                   (4, 'otro'),
                   (5, 'Embutidos'),
                   (6, 'Verdura'),
                   (7, 'otro'),
                   (8, 'Verdura'),
                   (9, 'Embutidos'),
                   (10, 'Verdura')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS pedidos";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE pedidos (id_encargo INT PRIMARY KEY, nombre varchar(100), apellido varchar(100), correo varchar(100), telefono varchar(9), num_producto INT, Confirmar_correo varchar(100), seleccione_producto varchar(100), comentarios varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO pedidos (id_encargo, nombre, apellido, correo, telefono, num_producto, Confirmar_correo, seleccione_producto, comentarios) VALUES
                   (1, 'Karla ', 'Lopez', 'karla@gmail.com', '61348997', 30, 'karla@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (2, 'Michael ', 'Rivas', 'michael@mail', '61794991', 20, 'michael@mail@dh', 'Lote de Tomates--$45.00', '---'),
                   (3, 'Gabriela', 'Muñoz', 'gaby24@gmail.com', '71459801', 40, 'gaby24@gmail.com', 'Lote de Huevos---$32.00', '-'),
                   (4, 'Karla ', 'Lopez', 'karla@gmail.com', '61348997', 10, 'karla@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (5, 'Carlos', 'Lopez', 'carlos@gmail.com', '61348997', 50, 'carlos@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (6, 'Ariel', 'Barraza', 'ariel@gmail.com', '61348997', 60, 'ariel@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (7, 'Nelson', 'Rivas', 'nelson@gmail.com', '61348997', 12, 'nelson@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (8, 'Mariela ', 'Martinez', 'mariela@gmail.com', '61348997', 35, 'mariela@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (9, 'Yulissa ', 'Perez', 'yulissa@gmail.com', '61348997', 32, 'yulissa@gmail.com', 'Lote de Huevos---$32.00', '--'),
                   (10, 'Jorge', 'Gaitan', 'jorge@gmail.com', '61348997', 31, 'jorge@gmail.com', 'Lote de Huevos---$32.00', '--')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS contabilidad";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE contabilidad (id_ingreso INT PRIMARY KEY, dia date, cant_ingresos_dia varchar(50), cant_egresaron_empresa varchar(50), detalle varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO contabilidad (id_ingreso, dia,cant_ingresos_dia,cant_egresaron_empresa, detalle) VALUES
                   (1, '2020-02-10', '400', '10,000', 'Utencilios'),
                   (2, '2020-05-14', '500', '12,000', 'Limpieza'),
                   (3, '2020-07-23', '600', '14,000', 'Ingredientes'),
                   (4, '2020-06-25', '700', '17,000', 'Pagos'),
                   (5, '2020-10-30', '400', '10,000', 'Extras'),
                   (6, '2020-12-31', '450', '11,500', 'Equipo Tecnico'),
                   (7, '2020-02-24', '300', '9,200', 'Limpieza'),
                   (8, '2020-01-07', '290', '8,340', 'Utencilios'),
                   (9, '2020-09-04', '2500', '7,200', 'Junta'),
                   (10, '2020-11-01', '90', '1,000', 'Promociones')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS comentarios";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE comentarios (Nombre varchar(50), id_trabajador INT PRIMARY KEY, genero varchar(2), dui varchar(10), fecha_visita date, correo varchar(100), sugerencias varchar(100))";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO comentarios (Nombre,id_trabajador, genero, dui, fecha_visita, correo, sugerencias) VALUES
                  ('Nicol Flores', 1, 'M', '13456-7', '2021-12-07', 'nicol@mail.com', 'Pago'),
                  ('Alexandra Barahona', 2, 'M', '134567-4', '2021-10-15', 'ale@mail.com', 'Horas Extra'),
                  ('Enrique Cubias', 3, 'H', '134567-5', '2021-09-03', 'enrique@mail.com', 'Deficiencia'),
                  ('William Avalos',4, 'H', '1345674-6', '2021-05-07', 'william@mail.com', 'Pago'),
                  ('Nikol Siguenza', 5, 'M', '1345674-8', '2021-03-12', 'nik@mail.com', 'Beneficios'),
                  ('Jose Alvarenga', 6, 'H', '1345674-9', '2021-07-09', 'jose@mail.com', 'Horas Extra'),
                  ('Idalia Rivas', 7, 'M', '1345674-10', '2021-08-11', 'ida@mail.com', 'Beneficios'),
                  ('Cecia Nohemy', 8, 'M', '1345674-11', '2021-10-20', 'cecia@mail.com', 'Pago'),
                  ('Cristian De Paz', 9, 'H', '1345674-12', '2021-01-02', 'cristian@mail.com', 'Deficiencia'),
                  ('Alexa Lopez', 10, 'M', '1345674-13', '2021-02-10', 'alexa@mail.com', 'Horas Extra')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS areaventas";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE areaventas (id_venta INT PRIMARY KEY, fecha date, cant_ventas_mes INT, dinero_total varchar(50), cant_trabajadores INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		//Agregando 10 registros
		$consulta="INSERT INTO areaventas (id_venta, fecha,cant_ventas_mes, dinero_total, cant_trabajadores) VALUES
                  (1, '2021-12-01', 20, '400', 20),
                  (2, '2021-05-06', 71, '300', 100),
                  (3, '2021-04-03', 25, '450', 30),
                  (4, '2021-12-06', 60, '500', 35),
                  (5, '2021-01-07', 85, '700', 40),
                  (6, '2021-03-09', 90, '720', 50),
                  (7, '2021-08-13', 120, '950', 30),
                  (8, '2021-05-02', 200, '1500', 90),
                  (9, '2021-11-04', 150, '1000', 50),
                  (10, '2021-10-24',79, '650', 25)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS usuario";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE usuario (id_usuario INT PRIMARY KEY AUTO_INCREMENT,nombre varchar(50),dui varchar(12), correo varchar(50), contraseña varchar(10), categoria varchar(15) DEFAULT 'empleado')";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="INSERT INTO usuario (nombre,dui, correo, contraseña, categoria) VALUES
                  ('Michael Alvarenga', '0100-0','michael@mail.com', 'clay10', 'admin'),
                  ('William Alexis', '0200-1','william@mail.com','will10',DEFAULT),
                  ('Cecia Nohemy','0300-2','cecia@mail.com','ces10',DEFAULT),
                  ('Idalia Rivas','0400-3','idalia@mail.com','ida10',DEFAULT),
                  ('Helen Flores','0500-4','helen@mail.com','hel10',DEFAULT),
                  ('Alexa Lopez','0600-5','alexa@mail.com','ale10',DEFAULT),
                  ('Enrique Cubias','0700-6','enrique@mail.com','enri10',DEFAULT),
                  ('Cristian De Paz','0800-7','cristian@mail.com','cris10',DEFAULT),
                  ('Nikol Siguenza','0900-8','nikol@mail.com','nik10',DEFAULT),
                  ('Jose Alvarenga','100-9','jose@mail.com','jose10',DEFAULT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado
                   ADD CONSTRAINT usuario_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES usuario (id_usuario)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		$consulta="DROP TABLE IF EXISTS empleado_comentario";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_comentario (id_empleado INT, id_trabajador INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_comentario
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_trabajador (id_trabajador)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		$consulta="DROP TABLE IF EXISTS empleado_contabilidad";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_contabilidad (id_empleado INT, id_ingreso INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_contabilidad
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_ingreso (id_ingreso)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS empleado_pedido";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_pedido (id_empleado INT, id_encargo INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_pedido
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_encargo (id_encargo)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		$consulta="DROP TABLE IF EXISTS empleado_producto";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_producto (id_empleado INT, id_producto INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_producto
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_producto (id_producto)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE sucursal_proveedor (id_sucursales INT, id_proveedor INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE sucursal_proveedor
                   ADD KEY id_sucursales (id_sucursales),
                   ADD KEY id_proveedor (id_proveedor)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE sucursal_proveedor
                   ADD CONSTRAINT sucursal_proveedor_ibfk_1 FOREIGN KEY (id_sucursales) REFERENCES sucursal (id_sucursales),
                   ADD CONSTRAINT sucursal_proveedor_ibfk_2 FOREIGN KEY (id_proveedor) REFERENCES proveedores (id_proveedor)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		
		$consulta="DROP TABLE IF EXISTS empleado_publicidad";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_publicidad (id_empleado INT, id_publicidad INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_publicidad
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_publicidad (id_publicidad)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="DROP TABLE IF EXISTS empleado_venta";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="CREATE TABLE empleado_venta (id_empleado INT, id_venta INT)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_venta
                   ADD KEY id_empleado (id_empleado),
                   ADD KEY id_venta (id_venta)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_comentario
                   ADD CONSTRAINT empleado_comentario_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_comentario_ibfk_2 FOREIGN KEY (id_trabajador) REFERENCES comentarios (id_trabajador)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		$consulta="ALTER TABLE empleado_contabilidad
                   ADD CONSTRAINT empleado_contabilidad_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_contabilidad_ibfk_2 FOREIGN KEY (id_ingreso) REFERENCES contabilidad (id_ingreso)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_pedido
                   ADD CONSTRAINT empleado_pedido_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_pedido_ibfk_2 FOREIGN KEY (id_encargo) REFERENCES pedidos (id_encargo)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_producto
                   ADD CONSTRAINT empleado_producto_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_producto_ibfk_2 FOREIGN KEY (id_producto) REFERENCES producto (id_producto)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_publicidad
                   ADD CONSTRAINT empleado_publicidad_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_publicidad_ibfk_2 FOREIGN KEY (id_publicidad) REFERENCES publicidad (id_publicidad)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		$consulta="ALTER TABLE empleado_venta
                   ADD CONSTRAINT empleado_venta_ibfk_1 FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado),
                   ADD CONSTRAINT empleado_venta_ibfk_2 FOREIGN KEY (id_venta) REFERENCES areaventas (id_venta)";
		$EjecutarConsulta=mysqli_query($conexion,$consulta);
		
		
		
		
		
		
		//Verificando si la Base de datos se creo.
		if($EjecutarConsulta)
		{
			echo ("Base de datos creada de forma satisfactoria.<br>");
		}
		else
		{
			echo("Surgio problema para crear la Base de Datos.<br>");
			echo("El problema es: <br>");
			echo("Codigo de error: <b>".mysqli_errno($conexion)."</b><br>");
		}
		
		mysqli_close($conexion);
	?>
	</body>
</html>