<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contabilidad</title>
    <link rel="stylesheet" href="css/contabilidad.css">
	<style type="text/css">
	input[type=button],input[type=submit]
	{
	  background-color:#41D00F;
	  border:none;
	  color:black;
	  font-weigth:bold;
	  padding:6px 20px;
	  text-aling:center;
	  font-size:16px;
	  margin:4px 4px;
	  box-shadow:3px 3px 3px black;
	  position:center;
	  font-family:Arial;
	}
	</style>
</head>
<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="indexEmp.php">Inicio</a>
            </li>
            <li>
                <a href="Empleado.php">Ingresar nuevo personal</a>
            </li>
            <li class="active">
                <a href="contabilidadEmp.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentariosEmp.php">Comentarios</a>
            </li>
            <li>
                <a href="cerrar_sesion.php">Cerrar Sesion</a>
            </li>			
        </ul>
    </nav>
    
    <div class="container">
        <div class="container_form">
            <h1>Area contable</h1>
            <form method="POST" action="registrarContabilidadEmp.php">
                <div>
                    <br><label for="encargado: ">ID Ingresos</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="cod4" name="encargado" maxlength="12" required>
                </div>
                <div>
                    <br><label for="dia: ">Seleccione el dia</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="date" id="Dia" name="dia" required>
                </div>
                <div>
                    <br><label for="Nombre_Empresa: ">Cantidad de ingresos en el dia</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="cantIngresos" name="cant_ingresos" maxlength="50" required>
                </div>
                <div>
                    <br><label for="sueldo: ">Cantidad de dinero que  egresaron de la empresa</label></br>
                    <input style="WIDTH: 280px; height: 20px;" type="text" id="cantEgresos" name="cant_egresos" maxlength="50" required>
                </div>
                <div>
                    <br><label for="cant_clientes: ">Detallar en que fue gastado el dinero </label></br>
                    <p> <textarea id="Comentarios" name="Comentarios" rows="10" cols = "50"> </textarea> </p>

                </div>
                <input class="boton" type="submit" name="registrar" value="Registrar">
            </form>
        </div>
    </div>

    <div class="footer">
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
    </div>

</body>
</html>