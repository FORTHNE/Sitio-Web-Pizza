<?php
require('conexion.php');

$id_encargo=$_POST['id_encargo'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$correo=$_POST['correo'];
$telefono=$_POST['telefono'];
$id_producto=$_POST['id_producto'];
$confirmar=$_POST['confirmar'];
$seleccione=$_POST['producto'];
$comentarios=$_POST['comentarios'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO pedidos (id_encargo,nombre,apellido,correo,telefono,num_producto,Confirmar_correo,seleccione_producto,	comentarios) VALUES('$id_encargo','$nombre','$apellido','$correo','$telefono','$id_producto','$confirmar','$seleccione','$comentarios')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalPedidos.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE pedidos SET nombre='$nombre',apellido='$apellido',correo='$correo',telefono='$telefono',num_producto='$id_producto',Confirmar_correo='$confirmar',seleccione_producto='$seleccione',comentarios='$comentarios' WHERE id_encargo='$id_encargo'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalPedidos.php');
	}
	else
	{
		echo 'Error al actualizar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM pedidos WHERE id_encargo='$id_encargo'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalPedidos.php');
	}
	else
	{
		echo 'Error al eliminar';
	}
}
?>