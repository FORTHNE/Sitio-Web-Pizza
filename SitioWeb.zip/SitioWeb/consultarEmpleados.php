<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleados</title>
    <link rel="stylesheet" href="empleado.css">
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>

	<nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li class=" active">
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
			<li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>

	<div class="container">
		<div class="container_form">
			<h1>REGISTRAR PERSONAL</h1>
			<form name="frmDatos" method="POST" action="registrarNuevo.php">

				<p> Nombre empleado: </p>  
				<input type="text" id="nom" name="nombre" size="15" maxlength="20" required>

				<p>DUI:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="dui" name="dui" maxlength="20" required>

				<p>Email:</p>
				<input type="email" id="correo" name="correo" size="30" maxlength="25" required>

				<p>Contraseña:</p>
				<input class="controls" type="password" name="contraseña" id="contraseña" placeholder="Ingrese su Contraseña" required><br>
				<br>

				<input class="boton" type="submit" name="registrar" value="Registrar">
				<input class="boton" type="submit" name="actualizar" value="Actualizar">
				<input class="boton" type="submit" name="eliminar" value="Eliminar">
			</form>
		</div>
		<center><table border="3px"></center>
		<tr><td colspan="5" align="center"><label>Listado de Usuarios</label></td></tr>
		<tr>
		<td></label>Id Usuario</label></td>
		<td><label>Nombre</label></td>
		<td><label>Dui</label></td>
		<td><label>Correo</label></td>
		<td><label>Contraseña</label></td>
		</tr>
			<?php
			$sql="SELECT*FROM usuario";
	    	$result=mysqli_query($conexion,$sql);
	 			 
		         while ($row = mysqli_fetch_array($result))
			{
				echo "<tr>";
				echo "<td>",$row ['id_usuario'],"</td>","<td>",$row ['nombre'],"</td>","<td>",$row ['dui'],"</td>","<td>",$row['correo'],"</td><td>",$row['contraseña'],"</td>";
				echo "</tr>";
			}
			echo "</table>";
				 
				?>
				</table>
				
				
	</div>
		<footer>
			<p>Derechos Reservados Pizza Nova&copy;.</p>
		</footer>

</body>
</html>