<?php
require('conexion.php');



session_start();
$correo=$_POST['correo'];
$contraseña=$_POST['contraseña'];
$_SESSION['correo']=$correo;



$consulta="SELECT*FROM usuario where correo='$correo' and contraseña='$contraseña'";
$resultado=mysqli_query($conexion,$consulta);



$filas=mysqli_fetch_array($resultado);
if($filas['categoria']=="admin"){
header('location:index.php');
}else
if($filas['categoria']=="empleado"){
header('location:indexEmp.php');
}
else
{
?>
<?php
include("iniciar_sesion.php");
?>
<h1 class="bad">Error en la autenticacion</h1>
<?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);
?>