<?php
include('registrarPubli.php');
include('publicidad.php');
?>