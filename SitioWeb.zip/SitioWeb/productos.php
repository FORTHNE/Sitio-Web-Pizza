<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comentarios</title>
    <link rel="stylesheet" href="empleado.css">
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li class=" active">
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>

    <div class="container">
        <div class="container_form">
            <h1>Productos en existencia</h1>
            <form method="POST" action="registrarProducto.php">
                <div>
                    <br><label for="encargado: ">ID Producto</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="cod1" name="id_pro" required>
                </div>
        
                <div>
                <p><br>Seleccione los productos que quiere consultar, guardar o agregar</p> <br>
                    <select name="estilo" style="width: 280px; height: 40px;">
                        <option value="seleccionar">Selecciona
                        <option value="Harina">Harina
                        <option value="Verdura">Verdura
                        <option value="Embutidos">Embutidos
                        <option value="Aderesos">Aderesos
                        <option value="otro">Otros
                    </select>
                </div>

                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
            </form>
        </div>
		 <center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Lista de Productos</label></td></tr>
        <tr>
        <td><label>Id Producto</label></td>
        <td><label>Producto Seleccionado</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM producto";
            $result=mysqli_query($conexion,$sql);
                 
                 while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['id_producto'],"</td><td>",$row ['seleccione_producto'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
    </div>    
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
</body>
</html>