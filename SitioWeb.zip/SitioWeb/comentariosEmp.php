<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comentarios</title>
    <link rel="stylesheet" href="css/comentario.css">
			<style type="text/css">
	input[type=button],input[type=submit]
	{
	  background-color:#41D00F;
	  border:none;
	  color:black;
	  font-weigth:bold;
	  padding:6px 20px;
	  text-aling:center;
	  font-size:16px;
	  margin:4px 4px;
	  box-shadow:3px 3px 3px black;
	  position:center;
	  font-family:Arial;
	}
	</style>
</head>
<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="indexEmp.php">Inicio</a>
            </li>
            <li>
                <a href="Empleado.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="contabilidadEmp.php">Contabilidad</a>
            </li>
            <li class=" active">
                <a href="comentariosEmp.php">Comentarios</a>
            </li>  
            <li>
                <a href="cerrar_sesion.php">Cerrar Sesion</a>
            </li>			
        </ul>
    </nav>

    <div class="container">
        <div class="container_form">
            <h1>FORMULARIO DE CONSULTAS</h1>
            <form action ="registrarComentariosEmp.php" method ="POST">
                <p>Nombre:</p>
                <input type="text"  id="nomb" name="nombre" size="35" class = "field" maxlength="50" placeholder="Nombre completo..." required> 

                <p>ID Trabajador:</p> 
                <input type="text"  id="idtrabajador" name="id_trabajador" size="35" class = "field" maxlength="50" placeholder="Id Trabajador..." required>

                <p>Genero: </p>
                <input type="radio" id="Genero" name = "genero" class="field" value = "H" required> Hombre
                <input type="radio" id="Genero" name = "genero" class = "field" value ="M" required> Mujer

                <p> DUI (Sin Gui&oacuten)</p>
                <input type = "tel" id="dui" name = "DUI" maxlength = "9" placeholder="DUI" class ="field"  required>

                <p>Fechas de su visita:</p>
                <input type ="date" id="fecVisita" name = "fecha_visita" required>

                <p> Correo de contacto:</p>
                <input type ="email" id="correo" name = "correo_contacto" placeholder="E-mail" required>

                <p>&iquestC&oacutemo podemos mejorar? D&eacutejanos tus comentarios aquí, o alguna observacion a un empleado</p>
                <textarea id="comentario" name="Comentarios" rows="10" cols = "50"> </textarea><br>
				
                <input class="boton" type="submit" name="registrar" value="Registrar">
            </form>
        </div>
    </div>

    <div class="footer">
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
    </div>
</body>
</html>