<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css\contabilidad.css">
    <style type="text/css">
input[type=button],input[type=submit]
{
background-color:#41D00F;
border:none;
color:black;
font-weigth:bold;
padding:6px 20px;
text-aling:center;
font-size:16px;
margin:4px 4px;
box-shadow:3px 3px 3px black;
position:center;
font-family:Arial;
}

input:hover{
	color:red;
}
</style>
</head>
<body>

	<nav class="navbar navbar-main">
    </nav>

	<div class="container">

		<div class="container_form">
			<h1>INICIAR SESION</h1>
			<form name="frmDatos" method="POST" action="logueo.php">

				<p>Correo Electronico: </p>  
				<input style="WIDTH: 280px; height: 20px;" type="email
				" id="correo" name="correo"  maxlength="20" required>

				<p>Password:</p>
				<input  style="WIDTH: 200px; height: 20px;" type="password" id="contraseña" name="contraseña" maxlength="20" required><br>

				<br><center><input type="submit" value="Ingresar"></center>
				<br>
				<center><a href="crear_BD.php">Crear Base de Datos Aqui</a></center>
			</form>
		</div>
	</div>

	<div class="footer">
		<footer>
			<p>Derechos Reservados Pizza Nova&copy;.</p>
		</footer>
	</div>

</body>
</html>