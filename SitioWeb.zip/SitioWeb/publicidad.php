<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleados</title>
    <link rel="stylesheet" href="empleado.css">
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="login.php">Empleados</a>
            </li>
            <li class=" active">
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="container_form">
            <h1>Publicidad</h1>
            <form name="frmDatos" method="POST" action="registrarPubli.php">
            <div>
                <br><label for="encargado: ">ID Publicidad</label></br>
                <input  style="WIDTH: 280px; height: 20px;" type="text" id="cod6" name="id_publicidad" maxlength="12" required>
            </div>

            <div>
                <br><label for="dia: ">Seleccione el dia</label></br>
                <input  style="WIDTH: 280px; height: 20px;" type="date" id="dia1" name="dia" required>
            </div>

            <div>
                <br><label for="Nombre_Empresa: ">Cantidad de dinero en publicidad al dia</label></br>
                <input  style="WIDTH: 280px; height: 20px;" type="text" id="DinePubli" name="cantidadDia" maxlength="50" required>
            </div>
        
            <div>
                <br><label for="cant_clientes: ">Cantidad de dinero en publicidad al mes</label></br>
                <input style="WIDTH: 280px; height: 20px;" type="text" id="cant_clientes" name="cantPubli" maxlength="50" required>
            </div>

            <div>
                <br><label for="cant_clientes: ">Cantidad de trabajadores en el area de publicidad</label></br>
                <input style="WIDTH: 280px; height: 20px;" type="number" id="cant_traba" name="publitraba" required>
            </div>

            <p><br>Seleccione los tipos de publicidad que se estan ocupando</p> <br>
            <select name="publicidad">
                <option>Banner,brouchore</option>
                <option>Tv, Radio</option>
                <option>Redes Sociales</option>
            <option>Cabinas moviles</option>
            </select><br>

                <br>
                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
            </form>
        </div>
		 <center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Listado de Publicidad</label></td></tr>
        <tr>
        <td><label>ID Publicidad</label></td>
        <td><label>Seleccione el dia</label></td>
        <td><label>Cantidad de dinero en publicidad al dia</label></td>
        <td><label>Cantidad de dinero en publicidad al mes</label></td>
        <td><label>Cantidad de trabajadores</label></td>
        <td><label>Seleccione lo tipos de publicidad</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM publicidad";
            $result=mysqli_query($conexion,$sql);
                 
                 while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['id_publicidad'],"</td><td>",$row ['dia'],"</td><td>",$row['cant_dinero_dia'],"</td><td>",$row['cant_dinero_mes'],"</td><td>",$row['cant_trabajadores'],"</td><td>",$row['tipos_publicidad'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
    </div>
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
</body>
</html>