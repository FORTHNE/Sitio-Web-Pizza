<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comentarios</title>
    <link rel="stylesheet" href="comentario.css">
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li class=" active">
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>

    <div class="container">
        <div class="container_form">
            <h1>FORMULARIO DE CONSULTAS</h1>
            <form name="frmDato" method="POST" action="registrarComentarios.php">
                <p>Nombre:</p>
                <input type="text"  id="nomb" name="nombre" size="35" class = "field" maxlength="50" placeholder="Nombre completo..." required> 

                <p>ID Trabajador:</p> 
                <input type="text"  id="idtrabajador" name="id_trabajador" size="35" class = "field" maxlength="50" placeholder="Id Trabajador..." required>

                <p>Genero: </p>
                <input type="radio" id="Genero" name = "genero" class="field" value = "H" required> Hombre
                <input type="radio" id="Genero" name = "genero" class = "field" value ="M" required> Mujer

                <p> DUI (Sin Gui&oacuten)</p>
                <input type = "tel" id="dui" name = "DUI" maxlength = "9" placeholder="DUI" class ="field"  required>

                <p>Fechas de su visita:</p>
                <input type ="date" id="fecVisita" name = "fecha_visita" required>

                <p> Correo de contacto:</p>
                <input type ="email" id="correo" name = "correo_contacto" placeholder="E-mail" required>

                <p>&iquestC&oacutemo podemos mejorar? D&eacutejanos tus comentarios aquí, o alguna observacion a un empleado</p>
                <textarea id="comentario" name="Comentarios" rows="10" cols = "50"> </textarea><br>

                <br>
                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
            </form>
        </div>
		<center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Comentarios</label></td></tr>
        <tr>
        <td><label>Nombre</label></td>
        <td><label>Id Trabajador</label></td>
        <td><label>Genero</label></td>
        <td><label>Dui</label></td>
        <td><label>Fecha</label></td>
        <td><label>Correo</label></td>
        <td><label>Observaciones</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM comentarios";
            $result=mysqli_query($conexion,$sql);
                 
                 while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['Nombre'],"</td><td>",$row ['id_trabajador'],"</td><td>",$row['genero'],"</td><td>",$row['dui'],"</td><td>",$row['fecha_visita'],"</td><td>",$row['correo'],"</td><td>",$row['sugerencias'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
    </div>
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
</body>
</html>