<?php
require('conexion.php');

$id_publicidad=$_POST['id_publicidad'];
$dia=$_POST['dia'];
$cantidadDia=$_POST['cantidadDia'];
$cantPubli=$_POST['cantPubli'];
$publitraba=$_POST['publitraba'];
$publicidad=$_POST['publicidad'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO publicidad (id_publicidad,dia,cant_dinero_dia,cant_dinero_mes,cant_trabajadores,tipos_publicidad) VALUES('$id_publicidad','$dia','$cantidadDia','$cantPubli','$publitraba','$publicidad')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalPubli.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE publicidad SET dia='$dia',cant_dinero_dia='$cantidadDia',cant_dinero_mes='$cantPubli',cant_trabajadores='$publitraba',tipos_publicidad='$publicidad' WHERE id_publicidad='$id_publicidad'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalPubli.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM publicidad WHERE id_publicidad='$id_publicidad'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalPubli.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['nuevo']))
{
	header('location:principalPubli.php');
}

?>