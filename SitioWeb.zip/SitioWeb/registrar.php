
<?php
require('conexion.php');

$nom=$_POST['nombre'];
$dui=$_POST['dui'];
$genero=$_POST['sexo'];
$estado=$_POST['estado'];
$cor=$_POST['correo'];
$contra=$_POST['contraseña'];
$direccion=$_POST['direccion'];
$fechaNacimiento=$_POST['nacimiento'];
$fechaTrabajo=date("Y-m-d H:m:s");
$plan=$_POST['medico'];
$telefono=$_POST['telefono'];

$sql="INSERT INTO usuario (nombre,dui,correo,direccion,sexo,estado,nacimiento,contraseña,telefono,fecha_trabajo,plan_medico) VALUES('$nom','$dui','$cor','$direccion','$genero','$estado','$fechaNacimiento','$contra','$telefono','$fechaTrabajo','$plan')";

$resultado=mysqli_query($conexion,$sql);

$sql2="SELECT * FROM usuario WHERE correo='$cor' and contraseña='$contra'";
$res=mysqli_query($conexion,$sql2);
$existe=mysqli_num_rows($res);

if($existe>0)
{
    echo'<meta http-equiv="refresh" content="1; url=empleados.html">';
}
else
{
    echo'<meta http-equiv="refresh" content="3; url=empleados.html">';
    echo 'error';
}

?>