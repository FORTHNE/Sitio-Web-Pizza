<?php
require('conexion.php');

$nombre=$_POST['nombre'];
$id_trabajador=$_POST['id_trabajador'];
$genero=$_POST['genero'];
$dui=$_POST['DUI'];
$fecha=$_POST['fecha_visita'];
$correo=$_POST['correo_contacto'];
$Comentarios=$_POST['Comentarios'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO comentarios (Nombre,id_trabajador,genero,dui,fecha_visita,correo,sugerencias) VALUES('$nombre','$id_trabajador','$genero','$dui','$fecha','$correo','$Comentarios')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalComentariosEmp.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}
?>