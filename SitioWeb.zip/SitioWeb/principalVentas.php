<?php
include('registrarVentas.php');
include('Ventas.php');
?>