<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sucursal</title>
    <link rel="stylesheet" href="empleado.css">
</head>
<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
    <nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
            <li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li>
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li class=" active">
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>

    <div class="container">
        <div class="container_form">
            <h1> Sucursales</h1>
            <form method="POST" action="registrarSucursal.php">
                <div>
                    <br><label for="encargado: ">ID Sucursal:</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="cod2" name="codSucursal" maxlength="6" required>
                </div>
                <div>
                    <br><label for="dia: ">Telefono de la sucursal:</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="telesuc" maxlength="12" name="telefonoSucur" required>
                </div>
                <div>
                    <br><label for="Nombre_Empresa: ">Nombre de la sucursal:</label></br>
                    <input  style="WIDTH: 280px; height: 20px;" type="text" id="Nombre_Empresa" maxlength="50" name="nombre_sucursal" required>
                </div>
                <div>
                    <br><label for="sueldo: ">Direccion:</label></br>
                    <input style="WIDTH: 280px; height: 20px;" type="text" id="dire" maxlength="100" name="direccion" required>
                </div>
                <div>
                    <br><label for="cant_clientes: ">Nombre del gerente:</label></br>
                    <input style="WIDTH: 280px; height: 20px;" type="text" id="Ngerente" maxlength="50" name="nombre_gerente" required>
                </div>

                <br>
                <input class="boton" type="submit" name="registrar" value="Registrar">
                <input class="boton" type="submit" name="actualizar" value="Actualizar">
                <input class="boton" type="submit" name="eliminar" value="Eliminar">
            </form>
        </div>
		<center><table border="3px"></center>
        <tr><td colspan="20" align="center"><label>Listado de Sucursales</label></td></tr>
        <tr>
        <td><label>ID Sucursal</label></td>
        <td><label>Telefono</label></td>
        <td><label>Nombre de la Sucursal</label></td>
        <td><label>Direccion</label></td>
        <td><label>Nombre del Gerente</label></td>
        </tr>
            <?php
            $sql="SELECT*FROM sucursal";
            $result=mysqli_query($conexion,$sql);
                 
            while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>",$row ['id_sucursales'],"</td><td>",$row ['telefono'],"</td><td>",$row['nombre_sucursal'],"</td><td>",$row['direccion'],"</td><td>",$row['nombre_gerente'],"</td>";
                echo "</tr>";
            }
            echo "</table>";
                 
                ?>
                </table>
    </div>
        <footer>
            <p>Derechos Reservados Pizza Nova&copy;.</p>
        </footer>
</body>
</html>