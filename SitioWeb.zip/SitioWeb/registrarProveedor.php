<?php
require('conexion.php');

$id_proveedor=$_POST['idprod'];
$nombre_completo=$_POST['nomCompl'];
$telefono=$_POST['telefono'];
$correo=$_POST['cor'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO proveedores (id_proveedor, Nombre_completo,telefono,correo) VALUES('$id_proveedor','$nombre_completo','$telefono','$correo')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalProveedores.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE proveedores SET Nombre_completo='$nombre_completo',telefono='$telefono',correo='$correo' WHERE id_proveedor='$id_proveedor'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalProveedores.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM proveedores WHERE id_proveedor='$id_proveedor'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalProveedores.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}
?>