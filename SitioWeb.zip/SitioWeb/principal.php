<?php
include('registrarNuevo.php');
include('consultarEmpleados.php');
?>