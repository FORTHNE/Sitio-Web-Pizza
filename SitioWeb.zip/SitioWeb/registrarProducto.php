<?php
require('conexion.php');

$ID_producto=$_POST['id_pro'];
$seleccione=$_POST['estilo'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO producto (id_producto,seleccione_producto) VALUES('$ID_producto','$seleccione')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalProducto.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE producto SET seleccione_producto='$seleccione' WHERE id_producto='$ID_producto'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalProducto.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM producto WHERE id_producto='$ID_producto'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalProducto.php');
	}
	else
	{
		echo 'Errro al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['nuevo']))
{
	header('location:principalProducto.php');
}

?>