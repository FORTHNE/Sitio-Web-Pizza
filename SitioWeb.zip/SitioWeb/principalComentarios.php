<?php
include('registrarComentarios.php');
include('comentarios.php');
?>