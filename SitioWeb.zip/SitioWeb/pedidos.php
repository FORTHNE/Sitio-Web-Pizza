<?php
require('conexion.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos Productos</title>
    <link rel="stylesheet" href="empleado.css">
</head>

<body>
	<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
header("Location:iniciar_sesion.php");
}
?>
	<nav class="navbar navbar-main">
        <img src="imagenes/logo.png" alt="Pizza Nova">
        <ul class="navbar men">
            <li>
                <a href="index.php">Inicio</a>
            </li>
            <li>
                <a href="Ventas.php">Area de ventas</a>
            </li>
            <li>
                <a href="consultarEmpleados.php">Ingresar nuevo personal</a>
            </li>
			<li>
                <a href="login.php">Empleados</a>
            </li>
            <li>
                <a href="publicidad.php">Area de publicidad</a>
            </li>
            <li class=" active">
                <a href="pedidos.php">Pedidos</a>
            </li>
            <li>
                <a href="sucursales.php">Sucursales</a>
            </li>
            <li>
                <a href="Proveedores.php">Proveedores</a>
            </li>
            <li>
                <a href="contabilidad.php">Contabilidad</a>
            </li>
        
            <li>
                <a href="comentarios.php">Comentarios</a>
            </li>
            <li>
                <a href="productos.php">Productos</a>
            </li>
			<li>
				<a href="cerrar_sesion.php">Cerrar Sesion</a>
			</li>
        </ul>
    </nav>

	<div class="container">
		<div class="container_form">
			<h1>PEDIDO PRODUCTO</h1>
			<form name="frmPedido" method="post" action="registrarPedidos.php">
				<p>ID Encargo:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="nom1" name="id_encargo" maxlength="20" required>

				<p>Nombre</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="nom1" name="nombre" maxlength="20" required>

				<p>Apellido</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="apelli1" name="apellido" maxlength="20" required>

				<p>Correo Electronico:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="email" id="correo1" name="correo" required>

				<p>Numero Telefonico:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="numtele" maxlength="12" name="telefono" required>

				<p>ID Producto:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="text" id="ancar" maxlength="12" name="id_producto" required>

				<p>Confirmar correo:</p>
				<input  style="WIDTH: 280px; height: 20px;" type="email" id="confirmar_correo" name="confirmar" required>

				<p>Seleccione el producto:</p>	
				<select name="producto" required>	
					<option>Seleccionar</option>						
					<option>Lote de Tomates--$45.00</option>	
					<option>Lote de Huevos---$32.00</option>						
					<option>Chile verde---$12.00</option>						
					<option>Cebollas---$6.00</option>						
					<option>Hongo, champiñon---$12.05</option>				
					<option>Lote de Harina---$60.00</option>						
					<option>entre otros..</option>	
				</select>

				<p>Comentarios</p>
				<textarea cols="60" name="comentarios" rows="4"></textarea><br>

				<br>
				<input class="boton" type="submit" name="registrar" value="Registrar">
				<input class="boton" type="submit" name="actualizar" value="Actualizar">
				<input class="boton" type="submit" name="eliminar" value="Eliminar">
			</form>
		</div>
        <center><table border="3px"></center>
		<tr><td colspan="20" align="center"><label>Listado de Pedidos</label></td></tr>
		<tr>
		<td><label>ID Encargo</label></td>
		<td><label>Nombre</label></td>
		<td><label>Apellido</label></td>
		<td><label>Correo</label></td>
	    <td><label>Telefono</label></td>
		<td><label>Id Producto</label></td>
		<td><label>Confirmar Correo</label></td>
		<td><label>Seleccione Producto</label></td>
		<td><label>Comentarios</label></td>
		</tr>
			<?php
			$sql="SELECT*FROM pedidos";
	    	$result=mysqli_query($conexion,$sql);
	 			 
		         while ($row = mysqli_fetch_array($result))
			{
				echo "<tr>";
				echo "<td>",$row ['id_encargo'],"</td><td>",$row ['nombre'],"</td><td>",$row['apellido'],"</td><td>",$row['correo'],"</td><td>",$row['telefono'],"</td><td>",$row['num_producto'],"</td><td>",$row['Confirmar_correo'],"</td><td>",$row['seleccione_producto'],"</td><td>",$row['comentarios'],"</td>";
				echo "</tr>";
			}
			echo "</table>";
				 
				?>
				</table>
	</div>
	<footer>
	<p>Derechos Reservados Pizza Nova&copy;.</p>
	</footer>
</body>
</html>