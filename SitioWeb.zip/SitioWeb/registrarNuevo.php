<?php
require('conexion.php');

$nom=$_POST['nombre'];
$dui=$_POST['dui'];
$cor=$_POST['correo'];
$contra=$_POST['contraseña'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO usuario (nombre, dui, correo, contraseña) VALUES ('$nom','$dui','$cor','$contra')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principal.php');
	}
	else
	{
		echo 'Sucedio un error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE usuario SET nombre='$nom',dui='$dui',correo='$cor',contraseña='$contra' WHERE dui='$dui'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principal.php');
	}
	else
	{
		echo 'Error al actualizar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM usuario WHERE dui='$dui'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principal.php');
	}
	else
	{
		echo 'Error al eliminar';
	}
}
?>