<?php
require('conexion.php');

$id_ingresos=$_POST['ID_ingresos'];
$dia=$_POST['dia'];
$cant_ingresos_dia=$_POST['cant_egresaron'];
$cant_egresaron_empresa=$_POST['cant_egresaron'];
$detalle=$_POST['Comentarios'];

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['registrar']))
{
	$sqlregistrar="INSERT INTO contabilidad (id_ingreso,dia,cant_ingresos_dia,cant_egresaron_empresa,detalle) VALUES('$id_ingresos','$dia','$cant_ingresos_dia','$cant_egresaron_empresa','$detalle')";
	if(mysqli_query($conexion,$sqlregistrar))
	{
		header('location:principalContabilidad.php');
	}
	else
	{
		echo 'Error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['actualizar']))
{
	$sqlactualizar="UPDATE contabilidad SET dia='$dia',cant_ingresos_dia='$cant_ingresos_dia',cant_egresaron_empresa='$cant_egresaron_empresa',detalle='$detalle' WHERE id_ingreso='$id_ingresos'";
	if(mysqli_query($conexion,$sqlactualizar))
	{
		header('location:principalContabilidad.php');
	}
	else
	{
		echo 'Error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['eliminar']))
{
	$sqleliminar="DELETE FROM contabilidad WHERE id_ingreso='$id_ingresos'";
	if(mysqli_query($conexion,$sqleliminar))
	{
		header('location:principalContabilidad.php');
	}
	else
	{
		echo 'Error al registrar';
	}
}

if($_SERVER['REQUEST_METHOD']=='POST' and isset ($_POST['nuevo']))
{
	header('location:principalContabilidad.php');
}

?>